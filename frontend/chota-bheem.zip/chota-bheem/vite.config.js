import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// Camera access (getUserMedia) requires a secure context.
// `npm run dev` on localhost is fine. To test on a phone on your
// wifi network, either use `vite --host` with HTTPS certs, or
// use a tunnel like `npx localtunnel --port 5173` / ngrok.
export default defineConfig({
  base: './',
  plugins: [react(), tailwindcss()],
  server: {
    host: true
  }
})
